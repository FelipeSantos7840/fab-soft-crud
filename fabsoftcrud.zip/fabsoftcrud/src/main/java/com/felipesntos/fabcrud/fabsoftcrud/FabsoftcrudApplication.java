package com.felipesntos.fabcrud.fabsoftcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FabsoftcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(FabsoftcrudApplication.class, args);
	}

}
