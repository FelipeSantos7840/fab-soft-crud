package com.felipesntos.fabcrud.fabsoftcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FabsoftcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
